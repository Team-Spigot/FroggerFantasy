﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BattleScript : MonoBehaviour
{
    
    public bool playerTurn;

    // Use this for initialization
    void Start ()
    {
        //List<StatScript> memberStats = new List<StatScript>();
    }

    // Update is called once per frame
    void Update ()
    {


    }

    public void TurnSelect ()
    {
        if (playerTurn)
        {
        }
        
    }
}
