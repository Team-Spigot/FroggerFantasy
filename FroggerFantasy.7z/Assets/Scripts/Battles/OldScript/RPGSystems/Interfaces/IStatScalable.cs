﻿using UnityEngine;
using System.Collections;

public interface IStatScalable {

    void ScaleStat(int level);
}
